/****** Object:  Table [dbo].[SMS_API_LOG]    Script Date: 11/25/2019 6:01:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SMS_API_LOG](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MOBILE_NO] [nvarchar](50) NULL,
	[SMS_CONTENT] [nvarchar](500) NULL,
	[SMS_TIME] [nvarchar](50) NULL,
	[STATUS] [varchar](10) NOT NULL,
	[SMS_RESPONSE] [nvarchar](500) NULL,
	[RESPONSE] [nvarchar](800) NULL,
	[CREATED_DATE] [datetime] NOT NULL,
 CONSTRAINT [PK_SMS_API_LOG] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

--------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[INSERT_SMS_MST]    Script Date: 11/25/2019 6:02:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--EXEC [INSERT_SMS_MST] '123456789','SMSM','23/10/2019',''
-- =============================================
-- Author:		ROSHAN PERINCHEERI
-- Create date: 23 / 11 / 2019
-- Description:	GETTING SMS DATA
-- =============================================
ALTER PROCEDURE [dbo].[INSERT_SMS_MST]
(
	@MOBILE_NO NVARCHAR(50),
	@SMS_CONTENT NVARCHAR(200),
	@SMS_TIME NVARCHAR(50),
	@SMS_MSG VARCHAR(500) OUTPUT,
	@STATUS VARCHAR(5) OUTPUT
)
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @COUPON_CODE VARCHAR(30)
	SET @SMS_MSG = ''
	SET @STATUS = '0'

	DECLARE @COUNT INT = 0
	SELECT @COUNT = COUNT(1) FROM SMS_MST WHERE RIGHT(MOBILE_NO,9) = RIGHT(@MOBILE_NO,9)

	IF @COUNT = 0
	BEGIN
		SET @COUPON_CODE = (SELECT CAST((RAND()*1000000) AS DECIMAL(6)))

		INSERT INTO SMS_MST (
				MOBILE_NO,
				SMS_CONTENT,
				SMS_TIME,
				CREATED_DATE,
				COUPON_CODE
				)
		VALUES( @MOBILE_NO,
				@SMS_CONTENT,
				@SMS_TIME,
				GETDATE(),
				@COUPON_CODE )

		SET @SMS_MSG = 'Your Coupon code is '+CAST(@COUPON_CODE AS VARCHAR(30))
		SET @STATUS = '1'
		
	END
	ELSE
	BEGIN
		SET @SMS_MSG = 'Coupon code is already generated for this mobile no'
		SET @STATUS = '0'
	END
END

GO

--------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[INSERT_API_LOG]    Script Date: 11/25/2019 6:02:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ROSHAN PERINCHEERI
-- Create date: 23 / 11 / 2019
-- Description:	INSERT API DATA
-- =============================================
CREATE PROCEDURE [dbo].[INSERT_API_LOG]
(
	@MOBILE_NO NVARCHAR(50),
	@SMS_CONTENT NVARCHAR(200),
	@SMS_TIME NVARCHAR(50),
	@STATUS VARCHAR(10),
	@SMS_RESPONSE VARCHAR(500),
	@RESPONSE VARCHAR(500)
)
AS
BEGIN

	SET NOCOUNT ON;

	INSERT INTO SMS_API_LOG (
			MOBILE_NO,
			SMS_CONTENT,
			SMS_TIME,
			STATUS,
			SMS_RESPONSE,
			RESPONSE,
			CREATED_DATE
			)
	VALUES( @MOBILE_NO,
			@SMS_CONTENT,
			@SMS_TIME,
			@STATUS,
			@SMS_RESPONSE,
			@RESPONSE,
			GETDATE())
	
END

GO


