﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication1.Utility
{
    public class csConfig
    {
        public static string connString = System.Configuration.ConfigurationManager.ConnectionStrings["MSMS"].ConnectionString;


        public static bool InsertSMSMasterData(string MobileNo, string SMSContent, string SMSTimeStamp, out string Msg)
        {
            bool Value = false;
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(connString))
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT_SMS_MST", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@MOBILE_NO", SqlDbType.VarChar).Value = MobileNo;
                        cmd.Parameters.Add("@SMS_CONTENT", SqlDbType.VarChar).Value = SMSContent;
                        cmd.Parameters.Add("@SMS_TIME", SqlDbType.VarChar).Value = SMSTimeStamp;

                        cmd.Parameters.Add("@SMS_MSG", SqlDbType.VarChar, 500);
                        cmd.Parameters["@SMS_MSG"].Direction = ParameterDirection.Output;
                        cmd.Parameters.Add("@STATUS", SqlDbType.VarChar, 5);
                        cmd.Parameters["@STATUS"].Direction = ParameterDirection.Output;

                        con.Open();
                        cmd.ExecuteNonQuery();

                        Msg = cmd.Parameters["@SMS_MSG"].Value.ToString();
                        Value = cmd.Parameters["@STATUS"].Value.ToString() == "1" ? true : false;
                    }
                }
                return Value;
            }
            catch (Exception Ex)
            {
                Msg = "Exception : Invalid data "; // Ex.Message;
                InsertAPILog(MobileNo, SMSContent, SMSTimeStamp, "False", Msg, Ex.Message);
                return Value;
            }
        }

        public static string InsertAPILog(string MobileNo, string SMSContent, string SMSTimeStamp,string Status, string SMSReponse , string Response)
        {
            try
            {
                DataTable dt = new DataTable();
                string SMSMsg = string.Empty;

                using (SqlConnection con = new SqlConnection(connString))
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT_API_LOG", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@MOBILE_NO", SqlDbType.VarChar).Value = MobileNo;
                        cmd.Parameters.Add("@SMS_CONTENT", SqlDbType.VarChar).Value = SMSContent;
                        cmd.Parameters.Add("@SMS_TIME", SqlDbType.VarChar).Value = SMSTimeStamp;
                        cmd.Parameters.Add("@STATUS", SqlDbType.VarChar).Value = Status;
                        cmd.Parameters.Add("@SMS_RESPONSE", SqlDbType.VarChar).Value = SMSReponse;
                        cmd.Parameters.Add("@RESPONSE", SqlDbType.VarChar).Value = Response;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        
                    }
                }
                return SMSMsg;
            }
            catch (Exception Ex)
            {
                return "Failed" + Ex.Message;
            }
        }
    }
}