﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApplication1.Controllers
{
    public class SMSController : ApiController
    {// POST api/values
        public string Post([FromBody]WebApplication1.Models.SMS sms)
        {
            string SharedAuthKey = System.Configuration.ConfigurationManager.AppSettings["SharedAuthKey"];
            string SMSContent = string.Empty, Error = string.Empty;
            bool Value = true;
            try
            {
                if (sms.AuthKey == null)
                {
                    Error = "Authentication is empty";
                    Value = false;
                }
                else if (sms.MobileNo == null)
                {
                    Error = "Mobile No is empty";
                    Value = false;
                }
                else if (sms.SMSContent == null)
                {
                    Error = "SMS Content is empty";
                    Value = false;
                }
                else if (sms.SMSTimeStamp == null)
                {
                    Error = "SMS Time Stamp is empty";
                    Value = false;
                }
                else if (SharedAuthKey != sms.AuthKey)
                {
                    Error = "Invalid authentication key";
                    Value = false;
                }
                if (!Value)
                {
                    Utility.csConfig.InsertAPILog(sms.MobileNo, sms.SMSContent, sms.SMSTimeStamp, "False", "Invalid data", Error);
                    return "Invalid data";
                }

                if(Utility.csConfig.InsertSMSMasterData(sms.MobileNo, sms.SMSContent, sms.SMSTimeStamp,out SMSContent))
                {
                    Utility.csConfig.InsertAPILog(sms.MobileNo, sms.SMSContent, sms.SMSTimeStamp, "True", SMSContent, "");
                    return SMSContent;
                }
                Utility.csConfig.InsertAPILog(sms.MobileNo, sms.SMSContent, sms.SMSTimeStamp, "True", SMSContent, "");
                return SMSContent;
            }
            catch (Exception Ex)
            {
                Utility.csConfig.InsertAPILog(sms.MobileNo, sms.SMSContent, sms.SMSTimeStamp, "False", "Exception : Invalid data ", Ex.Message);
                return "Exception : Invalid data "; // Ex.Message;
            }
        }
    }
}
