﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MichelinSMSPortal.Utility
{
    public class csConfig
    {
        public static string connString = System.Configuration.ConfigurationManager.ConnectionStrings["MSMS"].ConnectionString;

        public static DataTable GetSMSData_Query()
        {
            DataTable dt = new DataTable();
            string query = "select * from TEST";
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();

            // create data adapter
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            // this will query your database and return the result to your datatable
            da.Fill(dt);
            conn.Close();
            da.Dispose();

            return dt;
        }

        public static DataTable GetSMSData(string MobileNo,string Branch)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_SMS_DATA", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@MOBILE_NO", SqlDbType.VarChar).Value = MobileNo;
                    cmd.Parameters.Add("@BRANCH", SqlDbType.VarChar).Value = Branch;

                    con.Open();
                    // create data adapter
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    // this will query your database and return the result to your datatable
                    da.Fill(dt);
                }
            }
            return dt;
        }

        public static bool InsertSMSData(string MobileNo, string Name, string Email,string CouponCode,string Branch,string Createdby,out string Msg)
        {
            Msg = string.Empty;
            bool Value = false;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT_SMS_DATA", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@MOBILE_NO", SqlDbType.VarChar).Value = MobileNo;
                    cmd.Parameters.Add("@NAME", SqlDbType.VarChar).Value = Name;
                    cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar).Value = Email;
                    cmd.Parameters.Add("@COUPON_CODE", SqlDbType.VarChar).Value = CouponCode;
                    cmd.Parameters.Add("@BRANCH", SqlDbType.VarChar).Value = Branch;
                    cmd.Parameters.Add("@CREATED_BY", SqlDbType.VarChar).Value = Createdby;

                    cmd.Parameters.Add("@RESULT", SqlDbType.VarChar, 5);
                    cmd.Parameters["@RESULT"].Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@MSG", SqlDbType.VarChar, 300);
                    cmd.Parameters["@MSG"].Direction = ParameterDirection.Output;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    Msg = cmd.Parameters["@MSG"].Value.ToString();
                    Value = cmd.Parameters["@RESULT"].Value.ToString()=="1" ? true :false ;
                }
            }
            return Value;
        }

        public static bool SMSLogin(string UserID, string Password)
        {
            bool Value = false;
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("SMS_LOGIN", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@USER_ID", SqlDbType.VarChar).Value = UserID;
                    cmd.Parameters.Add("@PWD", SqlDbType.VarChar).Value = Password;

                    SqlParameter sqlParam = new SqlParameter("@IS_SUCCESS", DbType.Boolean);
                    sqlParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(sqlParam);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    var Val = cmd.Parameters["@IS_SUCCESS"].Value.ToString();

                    if (Val == "1") Value = true;

                }
            }

            return Value;
        }
    }
}