﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MichelinSMSPortal
{
    public partial class SMSList : System.Web.UI.Page
    {
        public static DataTable dtSMSData = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dtSMSData = Utility.csConfig.GetSMSData("","");
                RepterSMSData.DataSource = dtSMSData;
                RepterSMSData.DataBind();
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string FileName = "SMS_DATA_" + DateTime.Now.ToString("ddMMyyyyHHmmss")+ ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dtSMSData, "SMS_DATA");

                Response.Clear();
                Response.Buffer = true;
                Response.Charset = "";
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("content-disposition", "attachment;filename="+ FileName);
                using (MemoryStream MyMemoryStream = new MemoryStream())
                {
                    wb.SaveAs(MyMemoryStream);
                    MyMemoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                }
            }

        }

        protected void btnValidate_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }

        protected void btnSearchSMSData_Click(object sender, EventArgs e)
        {
            dtSMSData = Utility.csConfig.GetSMSData(txtMobile.Value, ddlBranch.Value);
            RepterSMSData.DataSource = dtSMSData;
            RepterSMSData.DataBind();
        }
    }
}