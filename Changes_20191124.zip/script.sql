
/****** Object:  StoredProcedure [dbo].[GET_SMS_DATA]    Script Date: 11/24/2019 5:55:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--EXEC GET_SMS_DATA '0561111111',''
-- =============================================
-- Author:		ROSHAN PERINCHEERI
-- Create date: 23 / 11 / 2019
-- Description:	GETTING SMS DATA
-- =============================================
CREATE PROCEDURE [dbo].[GET_SMS_DATA]
(
	@MOBILE_NO NVARCHAR(50)='',
	@BRANCH NVARCHAR(100)=''
)
AS
BEGIN

	IF @MOBILE_NO = '' SET @MOBILE_NO = NULL 
	IF @BRANCH = '' SET @BRANCH = NULL
	
	SELECT  MOBILE_NO,
			NAME,
			EMAIL,
			COUPON_CODE,
			BRANCH,
			CREATED_BY,
			CREATED_DATE  
	FROM SMS_DATA
	WHERE MOBILE_NO LIKE '%'+ISNULL(@MOBILE_NO,MOBILE_NO)+'%'
	AND LTRIM(RTRIM((BRANCH))) = ISNULL(@BRANCH,LTRIM(RTRIM(BRANCH)))
	ORDER BY CREATED_DATE DESC
	
END
GO





/****** Object:  StoredProcedure [dbo].[INSERT_SMS_DATA]    Script Date: 11/24/2019 5:55:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ROSHAN PERINCHEERI
-- Create date: 23 / 11 / 2019
-- Description:	GETTING SMS DATA
-- =============================================
CREATE PROCEDURE [dbo].[INSERT_SMS_DATA]
(
	@MOBILE_NO NVARCHAR(50),
	@NAME NVARCHAR(200),
	@EMAIL VARCHAR(50),
	@COUPON_CODE VARCHAR(30),
	@BRANCH NVARCHAR(100),
	@CREATED_BY VARCHAR(50),
	@MSG VARCHAR(300) OUTPUT,
	@RESULT VARCHAR(1) OUTPUT
)
AS
BEGIN

	SET NOCOUNT ON;
	SET @MSG = 'Invalid Coupon code. Please enter a valid coupon code, Thank you.'
	SET @RESULT = '0'

	DECLARE @COUNT INT = 0 
	SELECT @COUNT = COUNT(1) FROM SMS_MST 
	WHERE COUPON_CODE = @COUPON_CODE AND RIGHT(MOBILE_NO,9) = RIGHT(@MOBILE_NO,9) 
	
	IF @COUNT > 0
	BEGIN
		SET @COUNT = 0
		SELECT @COUNT = COUNT(1) FROM SMS_DATA 
		WHERE COUPON_CODE = @COUPON_CODE AND RIGHT(MOBILE_NO,9) = RIGHT(@MOBILE_NO,9)

		IF @COUNT = 0
		BEGIN
			INSERT INTO SMS_DATA (
					MOBILE_NO,
					NAME,
					EMAIL,
					COUPON_CODE,
					BRANCH,
					CREATED_BY,
					CREATED_DATE )
			VALUES( @MOBILE_NO,
					@NAME,
					@EMAIL,
					@COUPON_CODE,
					@BRANCH,
					@CREATED_BY,
					GETDATE() )
			SET @MSG = 'Coupon code validated successfully, Thank you.'
			SET @RESULT = '1'
		END
		ELSE
		BEGIN
			SET @MSG = 'Coupon code already validated, Thank you.'
			SET @RESULT = '0'
		END
	END
END

GO


