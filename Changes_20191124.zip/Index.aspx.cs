﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MichelinSMSPortal
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                btnSMSList.Visible = false;
                if (Session["USER_ID"] != null)
                {
                    btnSMSList.Visible = true;
                }
            }
        }
        
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string Msg = string.Empty;
            if (Utility.csConfig.InsertSMSData(txtMobile.Value, txtName.Value, txtEmail.Value, txtCouponCode.Value, ddlBranch.Value, "Admin", out Msg))
            {
                txtMobile.Value = "";
                txtName.Value = "";
                txtEmail.Value = "";
                txtCouponCode.Value = "";
                ddlBranch.SelectedIndex = 0;
            }
            Response.Write("<script>alert('" + Msg + "');</script>");
            txtName.Focus();
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (Utility.csConfig.SMSLogin(txtUserName.Value, txtPassword.Value))
            {
                Session["USER_ID"] = txtUserName.Value;
                Response.Redirect("SMSList.aspx");
            }
            else
            {
                string Msg = "User name or Password is wrong";
                Response.Write("<script>alert('" + Msg + "');</script>");
            }
        }

        protected void btnSMSList_Click(object sender, EventArgs e)
        {
            Response.Redirect("SMSList.aspx");
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtMobile.Value = "";
            txtName.Value = "";
            txtEmail.Value = "";
            txtCouponCode.Value = "";
            ddlBranch.SelectedIndex = 0;
            txtName.Focus();
        }
    }
}